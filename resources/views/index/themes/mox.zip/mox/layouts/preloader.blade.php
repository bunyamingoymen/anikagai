<!-- preloader -->
<div id="preloader">
    <div id="loading-center">
        <div id="loading-center-absolute">
            <img src="../../../user/mox/img/preloader.svg" alt="">
        </div>
    </div>
</div>
<!-- preloader-end -->